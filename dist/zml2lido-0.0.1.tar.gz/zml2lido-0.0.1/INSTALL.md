You'll need a version of M. Kay's Saxon that is not part of this package

> pip install git+https://github.com/mokko/zml2lido#egg=zml2lido

Or try this for editable install 
> cd zml2lido
> pip install -e .

The script lido.py is tailored to my needs; you might need to adapt it to 
yours.