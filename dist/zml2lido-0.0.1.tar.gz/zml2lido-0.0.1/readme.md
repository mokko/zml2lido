# zml2lido - Xslt that rewrites ZML to Lido

"zml" refers to Zetcom's "generic" xml format that comes out of MpRia's API.
* See: http://docs.zetcom.com/ws/ 
* For LIDO see http://www.lido-schema.org

Requires
* Saxon to run xslt newer than version 1: //http://saxon.sourceforge.net/

This mapping is specific to the installation of the SPK.

