"""lido.py - A quick and dirty toolbox for turning zml files into LIDO"""

__version__ = "0.0.1"

import argparse
from lido import LidoTool

def lido():
    parser = argparse.ArgumentParser(description="Little LIDO toolchin")
    parser.add_argument("-i", "--input", help="zml input file", required=True)
    parser.add_argument(
        "-j", "--job", help="pick job (localLido or smbLido)", required=True
    )
    parser.add_argument(
        "-f", "--force", help="force overwrite existing lido", action="store_true"
    )
    parser.add_argument("-v", "--validate", help="validate lido", action="store_true")
    args = parser.parse_args()

    if args.force:
        args.validate = True

    print(f"JOB: {args.job}")

    m = LidoTool(input=args.input, force=args.force, validation=args.validate)
    getattr(m, args.job)()
